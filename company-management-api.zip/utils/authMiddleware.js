const jwt = require('jsonwebtoken');
const { appLogger } = require('./applogger');

/**
 * This function verifies the JWT token passed to microservices.
 */
const authenticateToken = (req, res, next) => {
  let respObj = {};
  const refId = req.headers["meta-transid"] || req.headers["refid"] || "";
  try {
    const { headers : { token } } = req;
    const publicKey = decodeURIComponent(encodeURIComponent(global?.appConfig?.jwtCreds?.publicKey || ''));
    if (!token) {
      respObj.exceptions = [];
      respObj.exceptions.push({
        "type": "E",
        "code": 401,
        "message": "Authorization Token is missing",
        "detail": "Authorization Token is required, refId: " + refId
      });
      return res.status(401).send(respObj);
    }
    const data = jwt.verify(token, publicKey , {
      algorithms: global?.appConfig?.jwtCreds?.algorithms || ["RS256"] ,
    });
    appLogger.info(
      `ServiceName: digitalcommonmodulev1; functionName: verifyJWT; Location: Jwt verify; info: ${
        JSON.stringify(data)}`);
    if (!data) {
      respObj.exceptions = [];
      respObj.exceptions.push({
        "type": "E",
        "code": 401,
        "message": "Token is Invalid/Expired",
        "detail": "Authorization Token is invalid/expired, refId: " + refId
      });
      return res.status(401).send(respObj);
    }
    next()
  } catch (error) {
    appLogger.error(
      `ServiceName: digitalcommonmodulev1; functionName: verifyJWT; Location: Final catch block; ErrorMessage: ${
        JSON.stringify(error.stack) || error
      }`,
    );
    respObj.exceptions = [];
      respObj.exceptions.push({
        "type": "E",
        "code": 401,
        "message": error.message || "Token is Invalid/Expired",
        "detail": (error.message || "Authorization Token is invalid/expired, refId: ") + refId
      });
      return res.status(401).send(respObj);
  }
};

module.exports = authenticateToken;
