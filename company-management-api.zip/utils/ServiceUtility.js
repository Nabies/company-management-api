// utils/ServiceUtility.js

function getRefId() {
  return "Id-xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx".replace(/[xy]/g, (c) => {
    const r = Math.random() * 16 | 0;
    const v = c === "x" ? r : (r & 0x3 | 0x8);
    return v.toString(16);
  });
}

const appLogger = {
  info: (msg, refId) => {
    console.info(`[INFO] [${new Date().toISOString()}] [refId: ${refId}] ${msg}`);
  },
  debug: (msg, refId) => {
    console.debug(`[DEBUG] [${new Date().toISOString()}] [refId: ${refId}] ${msg}`);
  },
  error: (msg, refId) => {
    console.error(`[ERROR] [${new Date().toISOString()}] [refId: ${refId}] ${msg}`);
  }
};

module.exports = { getRefId, appLogger };
