
const Company = require('../dao/mongosedao');
const { getRefId } = require('../utils/ServiceUtility');
const { appLogger } = require('../utils/applogger');

// Get companies with filters
exports.getCompanies = async (req, res) => {
  const refId = getRefId();
  try {
    const filters = {};
    if (req.query.name) filters.name = new RegExp(req.query.name, 'i');
    if (req.query.industry) filters.industry = req.query.industry;
    if (req.query.location) filters.location = req.query.location;
    if (req.query.size) filters.size = req.query.size;
    const companies = await Company.find(filters);
    appLogger.info(`Fetched companies with filters: ${JSON.stringify(filters)}`, { refId });
    res.json({ refId, data: companies });
  } catch (err) {
    appLogger.error(`Error fetching companies: ${err.message}`, { refId });
    res.status(500).json({ refId, error: err.message });
  }
};

// Create a new company
exports.createCompany = async (req, res) => {
  const refId = getRefId();
  try {
    const company = new Company(req.body);
    await company.save();
    appLogger.info(`Created company: ${company._id}`, { refId });
    res.status(201).json({ refId, data: company });
  } catch (err) {
    appLogger.error(`Error creating company: ${err.message}`, { refId });
    res.status(400).json({ refId, error: err.message });
  }
};

// Update a company
exports.updateCompany = async (req, res) => {
  const refId = getRefId();
  try {
    const company = await Company.findByIdAndUpdate(req.params.id, req.body, { new: true });
    if (!company) {
      appLogger.error(`Company not found for update: ${req.params.id}`, { refId });
      return res.status(404).json({ refId, error: 'Company not found' });
    }
    appLogger.info(`Updated company: ${company._id}`, { refId });
    res.json({ refId, data: company });
  } catch (err) {
    appLogger.error(`Error updating company: ${err.message}`, { refId });
    res.status(400).json({ refId, error: err.message });
  }
};

// Delete a company
exports.deleteCompany = async (req, res) => {
  const refId = getRefId();
  try {
    const company = await Company.findByIdAndDelete(req.params.id);
    if (!company) {
      appLogger.error(`Company not found for delete: ${req.params.id}`, { refId });
      return res.status(404).json({ refId, error: 'Company not found' });
    }
    appLogger.info(`Deleted company: ${company._id}`, { refId });
    res.json({ refId, message: 'Company deleted' });
  } catch (err) {
    appLogger.error(`Error deleting company: ${err.message}`, { refId });
    res.status(400).json({ refId, error: err.message });
  }
};
